/**
 * ui.js
 * Terminal UI menggunakan chalk, ora, inquirer
 * Handle tampilan, menu, dashboard, log
 */

import chalk from 'chalk';
import inquirer from 'inquirer';
import Table from 'cli-table3';
import boxen from 'boxen';

// ── ASCII HEADER ─────────────────────────────────────────────────────

/**
 * Print ASCII header aplikasi
 */
export function printHeader() {
  const header = `
██╗  ██╗    ██████╗  ██████╗ ██╗   ██╗
╚██╗██╔╝    ██╔══██╗██╔═══██╗╚██╗ ██╔╝
 ╚███╔╝     ██████╔╝██║   ██║ ╚████╔╝ 
 ██╔██╗     ██╔══██╗██║   ██║  ╚██╔╝  
██╔╝ ██╗    ██████╔╝╚██████╔╝   ██║   
╚═╝  ╚═╝    ╚═════╝  ╚═════╝    ╚═╝   
`;

  console.clear();
  console.log(chalk.cyan.bold(header));
  console.log(chalk.yellow.bold("  X'Boy Linux Warming AI (Pro)"));
  console.log(chalk.gray('  ─────────────────────────────────────'));
  console.log(chalk.gray('  Human-like WhatsApp Chat Simulator'));
  console.log(chalk.gray('  ─────────────────────────────────────\n'));
}

/**
 * Print dashboard statistik global
 * @param {Object} stats - statistik global dari sessionManager
 * @param {string} period - periode waktu sekarang
 * @param {boolean} isRunning - apakah warming aktif
 * @param {boolean} hasApiKey - apakah API key sudah diset
 */
export function printDashboard(stats, period, isRunning, hasApiKey) {
  const statusBadge = isRunning
    ? chalk.bgGreen.black(' RUNNING ')
    : chalk.bgRed.white(' STOPPED ');

  const apiStatus = hasApiKey
    ? chalk.green('✓ Connected')
    : chalk.red('✗ Not Set');

  const dashboard = [
    `  Status Warming : ${statusBadge}`,
    `  Gemini AI      : ${apiStatus}`,
    `  Waktu          : ${chalk.cyan(period.toUpperCase())}`,
    ``,
    `  ${chalk.white('📊 Statistik Sesi')}`,
    `  Total Sesi     : ${chalk.yellow(stats.total)}`,
    `  Active         : ${chalk.green(stats.active)}`,
    `  Idle           : ${chalk.blue(stats.idle)}`,
    `  Offline        : ${chalk.gray(stats.offline)}`,
    `  Busy           : ${chalk.magenta(stats.busy)}`,
    ``,
    `  ${chalk.white('💬 Statistik Chat')}`,
    `  Total Terkirim : ${chalk.green(stats.totalSent)}`,
    `  Total Diterima : ${chalk.cyan(stats.totalReceived)}`,
    `  Total Percakpn : ${chalk.yellow(stats.totalConversations)}`,
  ].join('\n');

  console.log(boxen(dashboard, {
    padding: 1,
    borderStyle: 'round',
    borderColor: 'cyan',
    title: "  X'Boy Dashboard  ",
    titleAlignment: 'center',
  }));
  console.log('');
}

/**
 * Print list semua sesi dalam table
 * @param {Array} sessions - array semua sesi
 */
export function printSessionList(sessions) {
  if (sessions.length === 0) {
    console.log(chalk.yellow('  ⚠ Belum ada sesi. Tambah sesi dulu!\n'));
    return;
  }

  const table = new Table({
    head: [
      chalk.white('No'),
      chalk.white('Phone'),
      chalk.white('Nama'),
      chalk.white('Status'),
      chalk.white('Style'),
      chalk.white('Speed'),
      chalk.white('Sent'),
      chalk.white('Recv'),
    ],
    style: { border: ['gray'], head: [] },
  });

  sessions.forEach((s, i) => {
    const statusColor = {
      active: chalk.green,
      idle: chalk.blue,
      offline: chalk.gray,
      busy: chalk.magenta,
    }[s.status] || chalk.white;

    table.push([
      chalk[s.color](`${i + 1}`),
      chalk[s.color](s.phone),
      chalk[s.color](s.persona.name),
      statusColor(s.status),
      s.persona.style,
      s.persona.speed,
      chalk.green(s.stats.sent),
      chalk.cyan(s.stats.received),
    ]);
  });

  console.log(table.toString());
  console.log('');
}

/**
 * Print log chat ke terminal dengan warna per sesi
 * @param {Array} logs - array log dari statsTracker
 * @param {Array} sessions - array sesi (untuk mapping warna)
 */
export function printLogs(logs, sessions) {
  // Buat mapping phone -> color
  const colorMap = {};
  sessions.forEach(s => {
    colorMap[s.phone] = s.color;
  });

  if (logs.length === 0) {
    console.log(chalk.gray('  Belum ada log chat.\n'));
    return;
  }

  // Tampilkan 30 log terakhir
  const recentLogs = logs.slice(-30);
  recentLogs.forEach(log => {
    if (log.type === 'system') {
      console.log(chalk.bgBlue.white(`[${log.time}]`) + ' ' + chalk.blue(log.message));
    } else if (log.type === 'typing') {
      const color = colorMap[log.from] || 'white';
      console.log(
        chalk.gray(`[${log.time}]`) + ' ' +
        chalk[color](log.from) + chalk.gray(' is typing...')
      );
    } else {
      const fromColor = colorMap[log.from] || 'white';
      const toColor = colorMap[log.to] || 'white';
      console.log(
        chalk.gray(`[${log.time}]`) + ' ' +
        chalk[fromColor](log.from) + chalk.gray(' -> ') +
        chalk[toColor](log.to) + chalk.gray(': ') +
        chalk.white(log.message)
      );
    }
  });
  console.log('');
}

/**
 * Print statistik detail per sesi
 * @param {Array} sessions - array semua sesi
 */
export function printStats(sessions) {
  if (sessions.length === 0) {
    console.log(chalk.yellow('  Belum ada sesi.\n'));
    return;
  }

  sessions.forEach(s => {
    const lastActive = s.stats.lastActive
      ? new Date(s.stats.lastActive).toLocaleTimeString('id-ID')
      : 'Belum aktif';

    const block = [
      `  ${chalk[s.color].bold(s.persona.name)} (${s.phone})`,
      `  Status        : ${s.status}`,
      `  Personality   : ${s.persona.personality}`,
      `  Style         : ${s.persona.style}`,
      `  Speed         : ${s.persona.speed}`,
      `  Jam Aktif     : ${s.persona.activeHours.start}:00 - ${s.persona.activeHours.end}:00`,
      `  Pesan Terkirim: ${chalk.green(s.stats.sent)}`,
      `  Pesan Diterima: ${chalk.cyan(s.stats.received)}`,
      `  Percakapan    : ${chalk.yellow(s.stats.conversations)}`,
      `  Last Active   : ${chalk.gray(lastActive)}`,
    ].join('\n');

    console.log(boxen(block, {
      padding: { top: 0, bottom: 0, left: 1, right: 1 },
      borderStyle: 'single',
      borderColor: s.color,
    }));
    console.log('');
  });
}

/**
 * Tampilkan menu utama dan ambil pilihan user
 * @param {boolean} isRunning - apakah warming aktif
 * @returns {Promise<string>} pilihan menu
 */
export async function showMainMenu(isRunning) {
  const { choice } = await inquirer.prompt([
    {
      type: 'list',
      name: 'choice',
      message: chalk.cyan('Pilih menu:'),
      choices: [
        { name: `${chalk.green('1.')} Tambah Sesi`, value: '1' },
        {
          name: isRunning
            ? `${chalk.green('2.')} ${chalk.gray('Mulai Warming')} (Sudah Running)`
            : `${chalk.green('2.')} Mulai Warming`,
          value: '2',
          disabled: isRunning ? 'Sudah running' : false,
        },
        {
          name: isRunning
            ? `${chalk.green('3.')} Stop Warming ${chalk.red('(RUNNING)')}`
            : `${chalk.green('3.')} ${chalk.gray('Stop Warming')} (Tidak aktif)`,
          value: '3',
        },
        { name: `${chalk.green('4.')} Set API Key (Gemini)`, value: '4' },
        { name: `${chalk.green('5.')} Lihat Statistik`, value: '5' },
        { name: `${chalk.green('6.')} Lihat Log Chat`, value: '6' },
        { name: `${chalk.green('7.')} Lihat Sesi`, value: '7' },
        new inquirer.Separator(),
        { name: `${chalk.red('8.')} Keluar`, value: '8' },
      ],
    },
  ]);
  return choice;
}

/**
 * Prompt input API key
 * @returns {Promise<string>} API key yang diinput
 */
export async function promptApiKey() {
  const { apiKey } = await inquirer.prompt([
    {
      type: 'password',
      name: 'apiKey',
      message: chalk.cyan('Masukkan Gemini API Key:'),
      mask: '*',
    },
  ]);
  return apiKey;
}

/**
 * Prompt jumlah sesi yang ingin dibuat
 * @returns {Promise<number>} jumlah sesi
 */
export async function promptSessionCount() {
  const { count } = await inquirer.prompt([
    {
      type: 'number',
      name: 'count',
      message: chalk.cyan('Berapa sesi yang ingin dibuat?'),
      default: 2,
      validate: v => (v >= 2 && v <= 10) ? true : 'Min 2, Max 10 sesi',
    },
  ]);
  return count;
}

/**
 * Prompt konfirmasi sebelum aksi
 * @param {string} msg - pesan konfirmasi
 * @returns {Promise<boolean>}
 */
export async function promptConfirm(msg) {
  const { ok } = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'ok',
      message: chalk.yellow(msg),
      default: false,
    },
  ]);
  return ok;
}

/**
 * Print pesan sukses
 * @param {string} msg
 */
export function printSuccess(msg) {
  console.log(chalk.green(`\n  ✅ ${msg}\n`));
}

/**
 * Print pesan error
 * @param {string} msg
 */
export function printError(msg) {
  console.log(chalk.red(`\n  ❌ ${msg}\n`));
}

/**
 * Print pesan info
 * @param {string} msg
 */
export function printInfo(msg) {
  console.log(chalk.cyan(`\n  ℹ  ${msg}\n`));
}

/**
 * Pause dan tunggu user tekan Enter
 */
export async function pressEnterToContinue() {
  await inquirer.prompt([
    {
      type: 'input',
      name: '_',
      message: chalk.gray('Tekan Enter untuk kembali ke menu...'),
    },
  ]);
}
