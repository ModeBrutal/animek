/**
 * index.js
 * Entry point utama X'Boy Linux Warming AI (Pro)
 * Handle main loop, menu navigation, dan orchestration semua module
 */

import chalk from 'chalk';
import ora from 'ora';

import {
  createSession,
  getAllSessions,
  getGlobalStats,
  generatePairingCode,
  stopAllSessions,
} from './sessionManager.js';

import {
  startWarming,
  stopWarming,
  isWarmingRunning,
  setLogCallback,
} from './chatSimulator.js';

import { setApiKey, hasApiKey } from './aiEngine.js';
import { getTimePeriod, scheduleSessionActivity } from './scheduler.js';
import { getLogs } from './statsTracker.js';

import {
  printHeader,
  printDashboard,
  printSessionList,
  printLogs,
  printStats,
  showMainMenu,
  promptApiKey,
  promptSessionCount,
  promptConfirm,
  printSuccess,
  printError,
  printInfo,
  pressEnterToContinue,
} from './ui.js';

// ── LIVE LOG BUFFER ──────────────────────────────────────────────────
// Simpan log baru saat warming berjalan, ditampilkan di menu log
const liveLogBuffer = [];

/**
 * Callback untuk log dari chatSimulator
 * Tampilkan langsung ke console saat warming berjalan
 * @param {Object} log - log object
 */
function handleLog(log) {
  liveLogBuffer.push(log);
  if (liveLogBuffer.length > 100) liveLogBuffer.shift();
}

// Set log callback ke chatSimulator
setLogCallback(handleLog);

// ── HANDLER MENU ─────────────────────────────────────────────────────

/**
 * Handler: Tambah sesi baru
 * Generate sesi dengan persona random dan pairing code simulasi
 */
async function handleAddSession() {
  printHeader();
  printInfo('Tambah Sesi Baru');

  const count = await promptSessionCount();
  const spinner = ora(`Membuat ${count} sesi...`).start();

  const created = [];

  for (let i = 0; i < count; i++) {
    spinner.text = `Membuat sesi ${i + 1}/${count}...`;
    await new Promise(r => setTimeout(r, 500));

    const session = createSession();
    const pairingCode = generatePairingCode(session.id);

    created.push({ session, pairingCode });
  }

  spinner.succeed(chalk.green(`${count} sesi berhasil dibuat!`));
  console.log('');

  // Tampilkan info sesi yang dibuat beserta pairing code
  created.forEach(({ session, pairingCode }, i) => {
    const info = [
      `  Sesi ke-${i + 1}`,
      `  Phone    : ${chalk[session.color].bold(session.phone)}`,
      `  Persona  : ${session.persona.name} (${session.persona.personality}, ${session.persona.style})`,
      `  Speed    : ${session.persona.speed}`,
      `  Pairing  : ${chalk.yellow.bold(pairingCode)} ← Input ke WhatsApp`,
    ].join('\n');

    console.log(chalk.bgGray.white(`\n  ── Sesi ${i + 1} ──`) + '\n' + info);
  });

  console.log('');
  printInfo('Masukkan pairing code di atas ke WhatsApp Settings > Linked Devices > Link with Phone Number');
  await pressEnterToContinue();
}

/**
 * Handler: Mulai warming
 */
async function handleStartWarming() {
  printHeader();

  const sessions = getAllSessions();
  if (sessions.length < 2) {
    printError('Minimal butuh 2 sesi! Tambah sesi dulu.');
    await pressEnterToContinue();
    return;
  }

  const connected = sessions.filter(s => s.connected);
  if (connected.length < 2) {
    printError('Minimal 2 sesi harus sudah connected (pairing). Tambah dan pair sesi dulu.');
    await pressEnterToContinue();
    return;
  }

  printInfo(`Akan mulai warming dengan ${connected.length} sesi`);

  if (!hasApiKey()) {
    printInfo('Gemini API key belum diset. Warming akan menggunakan random message (70% default).');
  }

  const confirm = await promptConfirm('Mulai warming sekarang?');
  if (!confirm) return;

  // Update jadwal aktivitas berdasarkan waktu
  scheduleSessionActivity();

  const ok = startWarming();
  if (ok) {
    printSuccess('Warming dimulai! Chat akan muncul secara berkala.');
    printInfo('Kembali ke menu untuk lihat log atau stop warming.');
  } else {
    printInfo('Warming sudah berjalan.');
  }

  await pressEnterToContinue();
}

/**
 * Handler: Stop warming
 */
async function handleStopWarming() {
  printHeader();

  if (!isWarmingRunning()) {
    printInfo('Warming tidak sedang berjalan.');
    await pressEnterToContinue();
    return;
  }

  const confirm = await promptConfirm('Stop warming sekarang?');
  if (!confirm) return;

  stopWarming();
  printSuccess('Warming dihentikan. Semua sesi kembali idle.');
  await pressEnterToContinue();
}

/**
 * Handler: Set API Key Gemini
 */
async function handleSetApiKey() {
  printHeader();
  printInfo('Set Gemini API Key');
  console.log(chalk.gray('  Dapatkan API key di: https://aistudio.google.com/app/apikey\n'));

  const key = await promptApiKey();

  if (!key || key.trim().length < 10) {
    printError('API key tidak valid!');
    await pressEnterToContinue();
    return;
  }

  const spinner = ora('Menyimpan API key...').start();
  await new Promise(r => setTimeout(r, 800));

  setApiKey(key);
  spinner.succeed('API key berhasil disimpan!');
  printSuccess('Gemini AI sekarang aktif (30% AI hybrid mode).');
  await pressEnterToContinue();
}

/**
 * Handler: Lihat statistik detail
 */
async function handleViewStats() {
  printHeader();
  console.log(chalk.cyan.bold('  📊 Statistik Detail Per Sesi\n'));

  const sessions = getAllSessions();
  printStats(sessions);

  const global = getGlobalStats();
  console.log(chalk.cyan.bold('  🌐 Statistik Global'));
  console.log(chalk.white(`  Total Sesi        : ${global.total}`));
  console.log(chalk.white(`  Total Terkirim    : ${chalk.green(global.totalSent)}`));
  console.log(chalk.white(`  Total Diterima    : ${chalk.cyan(global.totalReceived)}`));
  console.log(chalk.white(`  Total Percakapan  : ${chalk.yellow(global.totalConversations)}`));
  console.log('');

  await pressEnterToContinue();
}

/**
 * Handler: Lihat log chat
 */
async function handleViewLogs() {
  printHeader();
  console.log(chalk.cyan.bold('  💬 Log Chat (30 terbaru)\n'));

  const sessions = getAllSessions();
  const logs = getLogs();

  if (liveLogBuffer.length > 0) {
    printLogs(liveLogBuffer, sessions);
  } else {
    printLogs(logs, sessions);
  }

  await pressEnterToContinue();
}

/**
 * Handler: Lihat daftar sesi
 */
async function handleViewSessions() {
  printHeader();
  console.log(chalk.cyan.bold('  📱 Daftar Sesi\n'));

  const sessions = getAllSessions();
  printSessionList(sessions);

  await pressEnterToContinue();
}

// ── MAIN LOOP ─────────────────────────────────────────────────────────

/**
 * Main loop aplikasi
 * Terus tampilkan header + dashboard + menu sampai user keluar
 */
async function main() {
  // Auto-update jadwal aktivitas setiap 5 menit
  setInterval(() => {
    if (isWarmingRunning()) {
      scheduleSessionActivity();
    }
  }, 5 * 60 * 1000);

  while (true) {
    printHeader();

    // Tampilkan dashboard
    const stats = getGlobalStats();
    const period = getTimePeriod();
    printDashboard(stats, period, isWarmingRunning(), hasApiKey());

    // Tampilkan menu dan ambil pilihan
    const choice = await showMainMenu(isWarmingRunning());

    // Handle pilihan
    switch (choice) {
      case '1': await handleAddSession(); break;
      case '2': await handleStartWarming(); break;
      case '3': await handleStopWarming(); break;
      case '4': await handleSetApiKey(); break;
      case '5': await handleViewStats(); break;
      case '6': await handleViewLogs(); break;
      case '7': await handleViewSessions(); break;
      case '8': {
        const confirm = await promptConfirm('Yakin keluar? Semua warming akan dihentikan.');
        if (confirm) {
          stopAllSessions();
          console.log(chalk.cyan('\n  Sampai jumpa! X\'Boy Warming AI\n'));
          process.exit(0);
        }
        break;
      }
    }
  }
}

// ── RUN ───────────────────────────────────────────────────────────────
main().catch(err => {
  console.error(chalk.red('\n  Fatal Error:'), err.message);
  process.exit(1);
});
