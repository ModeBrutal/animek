/**
 * statsTracker.js
 * Tracking statistik semua sesi dan global
 * Handle log chat history
 */

// Log chat global (untuk ditampilkan di UI)
const chatLogs = [];
const MAX_LOGS = 200;

/**
 * Tambah log chat baru
 * @param {string} fromPhone - nomor pengirim
 * @param {string} toPhone - nomor penerima
 * @param {string} message - isi pesan
 * @param {string} type - 'message' | 'typing' | 'system'
 */
export function addLog(fromPhone, toPhone, message, type = 'message') {
  const now = new Date();
  const timeStr = now.toTimeString().substring(0, 8); // HH:MM:SS

  const log = {
    time: timeStr,
    from: fromPhone,
    to: toPhone,
    message,
    type,
    timestamp: now,
  };

  chatLogs.push(log);

  // Jaga max log
  if (chatLogs.length > MAX_LOGS) {
    chatLogs.shift();
  }

  return log;
}

/**
 * Ambil semua log chat
 * @param {number} limit - max log yang diambil (default semua)
 * @returns {Array} array log
 */
export function getLogs(limit = 0) {
  if (limit > 0) return chatLogs.slice(-limit);
  return [...chatLogs];
}

/**
 * Clear semua log
 */
export function clearLogs() {
  chatLogs.length = 0;
}

/**
 * Format log menjadi string display
 * @param {Object} log - log object
 * @returns {string} formatted log string
 */
export function formatLog(log) {
  if (log.type === 'typing') {
    return `[${log.time}] ${log.from} is typing...`;
  }
  if (log.type === 'system') {
    return `[${log.time}] [SYSTEM] ${log.message}`;
  }
  return `[${log.time}] ${log.from} -> ${log.to}: ${log.message}`;
}

/**
 * Hitung ringkasan statistik dari logs
 * @returns {Object} summary statistik log
 */
export function getLogSummary() {
  const messages = chatLogs.filter(l => l.type === 'message');
  const senders = new Set(messages.map(l => l.from));

  return {
    totalLogs: chatLogs.length,
    totalMessages: messages.length,
    uniqueSenders: senders.size,
  };
}
