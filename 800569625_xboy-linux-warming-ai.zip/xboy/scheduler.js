/**
 * scheduler.js
 * Auto scheduler berdasarkan waktu
 * Atur aktivitas sesi berdasarkan jam
 */

import { getAllSessions, updateSessionStatus } from './sessionManager.js';

/**
 * Ambil periode waktu sekarang
 * @returns {string} 'pagi' | 'siang' | 'malam' | 'tengah_malam'
 */
export function getTimePeriod() {
  const hour = new Date().getHours();
  if (hour >= 5 && hour < 11) return 'pagi';
  if (hour >= 11 && hour < 17) return 'siang';
  if (hour >= 17 && hour < 23) return 'malam';
  return 'tengah_malam';
}

/**
 * Ambil level aktivitas berdasarkan waktu
 * @param {string} period - periode waktu
 * @returns {Object} config aktivitas
 */
export function getActivityLevel(period) {
  const levels = {
    pagi: {
      label: 'Low Activity',
      emoji: '🌅',
      activeChance: 0.3,      // 30% sesi aktif
      minDelaySec: 60,
      maxDelaySec: 180,
    },
    siang: {
      label: 'Medium Activity',
      emoji: '☀️',
      activeChance: 0.6,
      minDelaySec: 30,
      maxDelaySec: 90,
    },
    malam: {
      label: 'High Activity',
      emoji: '🌙',
      activeChance: 0.85,
      minDelaySec: 10,
      maxDelaySec: 45,
    },
    tengah_malam: {
      label: 'Sleep Mode',
      emoji: '😴',
      activeChance: 0.05,     // hampir semua offline
      minDelaySec: 300,
      maxDelaySec: 600,
    },
  };
  return levels[period] || levels.siang;
}

/**
 * Update status semua sesi berdasarkan jadwal waktu
 * Beberapa sesi random jadi offline, beberapa aktif
 */
export function scheduleSessionActivity() {
  const period = getTimePeriod();
  const activity = getActivityLevel(period);
  const sessions = getAllSessions();

  sessions.forEach(session => {
    // Skip jika sesi sedang busy (lagi chat)
    if (session.status === 'busy') return;

    const rand = Math.random();

    if (rand < activity.activeChance) {
      // Sesi aktif
      if (session.status !== 'active') {
        updateSessionStatus(session.id, 'active');
      }
    } else if (rand < activity.activeChance + 0.1) {
      // Sesi offline sementara
      updateSessionStatus(session.id, 'offline');
    } else {
      // Sesi idle
      if (session.status !== 'active') {
        updateSessionStatus(session.id, 'idle');
      }
    }
  });

  return { period, activity };
}

/**
 * Hitung delay chat berdasarkan periode waktu
 * @returns {number} delay dalam milidetik
 */
export function getScheduledDelay() {
  const period = getTimePeriod();
  const activity = getActivityLevel(period);
  const sec = Math.floor(
    Math.random() * (activity.maxDelaySec - activity.minDelaySec + 1)
  ) + activity.minDelaySec;
  return sec * 1000;
}

/**
 * Cek apakah sekarang waktu tidur (tidak ada aktivitas)
 * @returns {boolean}
 */
export function isSleepTime() {
  return getTimePeriod() === 'tengah_malam';
}
