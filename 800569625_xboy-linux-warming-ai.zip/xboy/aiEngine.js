/**
 * aiEngine.js
 * Engine AI menggunakan Gemini API untuk generate reply natural
 * Sistem hybrid: 30% AI, 70% random message
 */

import { GoogleGenerativeAI } from '@google/generative-ai';

// Simpan API key di memory (tidak perlu database)
let geminiApiKey = null;
let geminiClient = null;

// ── KUMPULAN PESAN RANDOM ─────────────────────────────────────────────

// Sapaan
const GREETINGS = [
  'hei', 'hai', 'halo', 'hey', 'woi', 'oi', 'bro', 'gas', 'yo', 'haloo'
];

// Respon umum santai
const CASUAL_REPLIES = [
  'iya bro', 'oh oke', 'wkwk iya', 'bener juga sih', 'hahaha',
  'serius?', 'masa sih', 'anjir beneran', 'wkwkwk', 'iya nih',
  'nah itu dia', 'bisa juga', 'hmm iya deh', 'lah kok gitu',
  'emg gitu', 'ya emang', 'bener banget', 'lol', 'haha iya',
  'oh ternyata', 'gitu ya', 'mantap', 'okesip', 'sip bro'
];

// Respon formal ringan
const FORMAL_REPLIES = [
  'iya memang begitu', 'betul sekali', 'aku setuju', 'oh begitu ya',
  'hmm menarik', 'aku pikir juga begitu', 'ya kamu benar',
  'memang iya sih', 'bisa jadi', 'aku rasa iya', 'oh oke aku ngerti',
  'sip terima kasih', 'noted ya', 'oke siap', 'aku paham'
];

// Topik obrolan random
const TOPICS = [
  'btw lu udah makan belom?', 'eh ngomong2 gimana kabar?',
  'btw itu gimana ceritanya?', 'lu lagi ngapain sekarang?',
  'eh iya bener', 'aku lagi males banget nih', 'udah pada tau blm',
  'kemarin aku liat yang aneh banget', 'wah serius itu?',
  'emang gitu sih', 'btw jadi gimana?', 'kok bisa gitu ya',
  'aku juga heran', 'kayanya iya deh', 'nanti aja deh',
  'aku lagi sibuk btw', 'besok aja ya', 'ntar gue kabarin',
  'iya deh nanti ku pikirin', 'gaskeun aja lah'
];

// Pesan tambahan (double message)
const FOLLOWUPS = [
  'eh iya btw', 'lupa bilang', 'oh iya satu lagi',
  'btw', 'nah ini dia', 'tambahan nih', 'wait', 'eh'
];

// Emoji random (tidak selalu muncul)
const EMOJIS = ['😂', '😏', '🔥', '😅', '😭', '👍', '😄', '🤣', '💀', '😩'];

/**
 * Set API key Gemini dari input user
 * @param {string} key - API key Gemini
 */
export function setApiKey(key) {
  geminiApiKey = key.trim();
  try {
    geminiClient = new GoogleGenerativeAI(geminiApiKey);
  } catch (e) {
    geminiClient = null;
  }
}

/**
 * Cek apakah API key sudah diset
 * @returns {boolean}
 */
export function hasApiKey() {
  return geminiApiKey !== null && geminiApiKey.length > 10;
}

/**
 * Tambahkan typo random ke pesan (efek human-like)
 * @param {string} text - teks asli
 * @returns {string} teks dengan typo
 */
function addTypo(text) {
  if (Math.random() > 0.2) return text; // 20% chance typo
  const typos = {
    'yang': 'yg', 'dengan': 'dgn', 'tidak': 'ga', 'sudah': 'udah',
    'belum': 'blom', 'sama': 'sm', 'karena': 'krna', 'juga': 'jg',
    'kalau': 'klo', 'itu': 'tuh', 'ini': 'ni', 'bisa': 'bsa',
    'untuk': 'utk', 'dari': 'dr', 'tapi': 'tp', 'nanti': 'ntr'
  };
  let result = text;
  for (const [word, typo] of Object.entries(typos)) {
    if (result.includes(word) && Math.random() > 0.5) {
      result = result.replace(word, typo);
    }
  }
  return result;
}

/**
 * Tambahkan emoji random (tidak selalu)
 * @param {string} text - teks pesan
 * @returns {string} teks dengan atau tanpa emoji
 */
function addEmoji(text) {
  if (Math.random() > 0.3) return text; // 30% chance emoji
  const emoji = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
  return `${text} ${emoji}`;
}

/**
 * Generate pesan random berdasarkan persona (fallback)
 * @param {Object} persona - persona sesi
 * @param {Array} context - context chat terakhir
 * @returns {string} pesan random
 */
function generateRandomMessage(persona, context = []) {
  const isSantai = persona.style === 'santai';
  const replies = isSantai ? CASUAL_REPLIES : FORMAL_REPLIES;

  // Pilih tipe pesan: reply, topik, atau greeting
  const rand = Math.random();
  let msg;

  if (rand < 0.4) {
    // Ambil reply dari pool
    msg = replies[Math.floor(Math.random() * replies.length)];
  } else if (rand < 0.7) {
    // Topik baru
    msg = TOPICS[Math.floor(Math.random() * TOPICS.length)];
  } else if (rand < 0.85) {
    // Kombinasi greeting + topik
    const greet = GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
    const topic = TOPICS[Math.floor(Math.random() * TOPICS.length)];
    msg = `${greet}, ${topic}`;
  } else {
    // Pure greeting
    msg = GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
  }

  // Tambah typo dan emoji
  msg = addTypo(msg);
  msg = addEmoji(msg);

  return msg;
}

/**
 * Generate reply menggunakan Gemini AI
 * @param {Object} persona - persona sesi
 * @param {Array} context - array chat context terakhir
 * @returns {Promise<string>} reply dari AI
 */
async function generateAiReply(persona, context = []) {
  if (!geminiClient) throw new Error('No API client');

  const model = geminiClient.getGenerativeModel({ model: 'gemini-pro' });

  const contextStr = context.slice(-3).map(c => `${c.from}: ${c.msg}`).join('\n');

  const prompt = `Kamu adalah ${persona.name}, seorang ${persona.personality === 'aktif' ? 'yang aktif dan ceria' : persona.personality === 'dingin' ? 'yang cuek dan jarang ngomong' : persona.personality === 'sibuk' ? 'yang sibuk dan singkat' : 'yang santai'}.

Gaya bahasa: ${persona.style === 'santai' ? 'pakai gw/lu, gaul, casual' : 'pakai aku/kamu, agak formal tapi tetap santai'}.

Context percakapan terakhir:
${contextStr || '(awal percakapan)'}

Balas dengan SATU kalimat singkat (1-15 kata), natural, dan sesuai karaktermu. Kadang typo, singkatan, atau pakai emoji (tapi jangan berlebihan). Jangan formal.`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();
    // Ambil kalimat pertama saja
    return text.split('\n')[0].substring(0, 100);
  } catch (e) {
    throw new Error(`AI error: ${e.message}`);
  }
}

/**
 * Main function: generate reply hybrid (AI + random)
 * 30% AI, 70% random
 * @param {Object} persona - persona sesi
 * @param {Array} context - context chat terakhir
 * @returns {Promise<string>} pesan yang akan dikirim
 */
export async function generateReply(persona, context = []) {
  // 30% pakai AI jika API key tersedia
  if (hasApiKey() && Math.random() < 0.30) {
    try {
      const aiMsg = await generateAiReply(persona, context);
      return addTypo(addEmoji(aiMsg));
    } catch (e) {
      // Fallback ke random jika AI gagal
    }
  }

  // 70% random message
  return generateRandomMessage(persona, context);
}

/**
 * Generate pesan kedua (untuk double message)
 * @param {Object} persona - persona sesi
 * @returns {string} pesan pendek sebagai followup
 */
export function generateFollowup(persona) {
  const followup = FOLLOWUPS[Math.floor(Math.random() * FOLLOWUPS.length)];
  const topic = TOPICS[Math.floor(Math.random() * TOPICS.length)];
  return addEmoji(`${followup} ${topic}`);
}
