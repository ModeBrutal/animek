# X'Boy Linux Warming AI (Pro)

Human-like WhatsApp Chat Simulator CLI — bot vs bot warming dengan AI hybrid.

---

## 📦 Cara Install

```bash
# 1. Clone atau extract folder
cd xboy-linux-warming-ai

# 2. Install dependencies
npm install

# 3. Jalankan aplikasi
npm start
```

**Requirement:**
- Node.js v18+ (support ES Modules)
- NPM v8+

---

## 🚀 Cara Run

```bash
npm start
# atau
node index.js
```

---

## 🔑 Cara Input API Key (Gemini)

1. Dapatkan API key gratis di: https://aistudio.google.com/app/apikey
2. Jalankan aplikasi
3. Pilih menu **"4. Set API Key (Gemini)"**
4. Paste API key kamu
5. API key tersimpan di memory (hilang jika app ditutup)

> Tanpa API key: warming tetap jalan menggunakan random message (70% mode)

---

## 📋 Fitur

- 🤖 AI hybrid Gemini (30% AI + 70% random)
- 💬 Chat bot vs bot antar sesi
- ⌨️ Typing simulation realistic
- 📱 Multi sesi dengan persona unik
- ⏰ Auto scheduler berdasarkan waktu
- 📊 Statistik real-time per sesi
- 🎨 Warna berbeda tiap sesi di terminal
- 😂 Random emoji system
- 🔄 Delay realistis (8-45 detik, kadang 1-5 menit)

---

## 📁 Struktur File

```
xboy/
├── index.js          # Entry point & main loop
├── sessionManager.js # Manage sesi WhatsApp
├── personaEngine.js  # Generate persona unik
├── aiEngine.js       # AI Gemini + random message
├── chatSimulator.js  # Simulator chat bot vs bot
├── scheduler.js      # Auto scheduler waktu
├── statsTracker.js   # Log & statistik
├── ui.js             # Terminal UI (chalk/inquirer)
├── package.json
└── README.md
```

---

## ⚠️ Catatan

- Pairing code yang ditampilkan adalah simulasi
- Untuk integrasi WhatsApp nyata, tambahkan library seperti `@whiskeysockets/baileys`
- Gunakan secara bertanggung jawab

---

Made with ❤️ by X'Boy
