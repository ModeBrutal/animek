/**
 * sessionManager.js
 * Manage semua sesi WhatsApp warming
 * Handle create, delete, start, stop sesi
 */

import { generatePersona, getSessionColor } from './personaEngine.js';

// Storage sesi di memory
const sessions = new Map();

// Counter untuk assign warna unik
let sessionColorIndex = 0;

/**
 * Generate nomor HP random format +62
 * @returns {string} nomor HP
 */
function generatePhoneNumber() {
  const prefixes = ['812', '813', '821', '822', '823', '851', '852', '853', '858', '859', '877', '878'];
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const suffix = Math.floor(Math.random() * 90000000 + 10000000);
  return `+62${prefix}${suffix}`;
}

/**
 * Generate ID sesi unik
 * @returns {string} session ID
 */
function generateSessionId() {
  return `sess_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
}

/**
 * Buat sesi baru
 * @param {string|null} customPhone - nomor HP custom (opsional)
 * @returns {Object} sesi yang dibuat
 */
export function createSession(customPhone = null) {
  const id = generateSessionId();
  const phone = customPhone || generatePhoneNumber();
  const persona = generatePersona();
  const color = getSessionColor(sessionColorIndex++);

  const session = {
    id,
    phone,
    persona,
    color,
    status: 'idle',          // idle | active | busy | offline
    pairingCode: null,       // kode pairing WhatsApp
    connected: false,
    stats: {
      sent: 0,
      received: 0,
      conversations: 0,
      lastActive: null,
    },
    chatContext: [],          // 3 chat terakhir
    chatInterval: null,       // interval object untuk stop
    createdAt: new Date(),
  };

  sessions.set(id, session);
  return session;
}

/**
 * Ambil sesi berdasarkan ID
 * @param {string} id - session ID
 * @returns {Object|null}
 */
export function getSession(id) {
  return sessions.get(id) || null;
}

/**
 * Ambil semua sesi
 * @returns {Array} array semua sesi
 */
export function getAllSessions() {
  return Array.from(sessions.values());
}

/**
 * Update status sesi
 * @param {string} id - session ID
 * @param {string} status - status baru
 */
export function updateSessionStatus(id, status) {
  const session = sessions.get(id);
  if (session) {
    session.status = status;
    session.stats.lastActive = new Date();
  }
}

/**
 * Tambah pesan ke context chat sesi
 * Max simpan 3 chat terakhir
 * @param {string} id - session ID
 * @param {Object} msg - {from, to, msg}
 */
export function addChatContext(id, msg) {
  const session = sessions.get(id);
  if (!session) return;
  session.chatContext.push(msg);
  // Jaga max 3 context
  if (session.chatContext.length > 3) {
    session.chatContext.shift();
  }
}

/**
 * Update statistik sesi
 * @param {string} id - session ID
 * @param {string} type - 'sent' | 'received' | 'conversation'
 */
export function updateStats(id, type) {
  const session = sessions.get(id);
  if (!session) return;
  if (type === 'sent') session.stats.sent++;
  if (type === 'received') session.stats.received++;
  if (type === 'conversation') session.stats.conversations++;
  session.stats.lastActive = new Date();
}

/**
 * Set interval chat pada sesi (untuk stop nanti)
 * @param {string} id - session ID
 * @param {any} interval - interval object
 */
export function setSessionInterval(id, interval) {
  const session = sessions.get(id);
  if (session) session.chatInterval = interval;
}

/**
 * Stop sesi dan bersihkan interval
 * @param {string} id - session ID
 */
export function stopSession(id) {
  const session = sessions.get(id);
  if (!session) return;
  if (session.chatInterval) {
    clearTimeout(session.chatInterval);
    session.chatInterval = null;
  }
  session.status = 'idle';
}

/**
 * Stop semua sesi aktif
 */
export function stopAllSessions() {
  for (const [id] of sessions) {
    stopSession(id);
  }
}

/**
 * Hapus sesi
 * @param {string} id - session ID
 */
export function deleteSession(id) {
  stopSession(id);
  sessions.delete(id);
}

/**
 * Ambil statistik global semua sesi
 * @returns {Object} stats global
 */
export function getGlobalStats() {
  const all = getAllSessions();
  return {
    total: all.length,
    active: all.filter(s => s.status === 'active').length,
    idle: all.filter(s => s.status === 'idle').length,
    offline: all.filter(s => s.status === 'offline').length,
    busy: all.filter(s => s.status === 'busy').length,
    totalSent: all.reduce((sum, s) => sum + s.stats.sent, 0),
    totalReceived: all.reduce((sum, s) => sum + s.stats.received, 0),
    totalConversations: all.reduce((sum, s) => sum + s.stats.conversations, 0),
  };
}

/**
 * Generate pairing code simulasi untuk WhatsApp
 * Format: XXXX-XXXX
 * @param {string} id - session ID
 * @returns {string} pairing code
 */
export function generatePairingCode(id) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const part1 = Array.from({length: 4}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const part2 = Array.from({length: 4}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const code = `${part1}-${part2}`;

  const session = sessions.get(id);
  if (session) {
    session.pairingCode = code;
    session.connected = true; // Simulasi connected
    session.status = 'idle';
  }
  return code;
}
