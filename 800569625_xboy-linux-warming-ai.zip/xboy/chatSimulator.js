/**
 * chatSimulator.js
 * Simulator chat antar sesi (bot vs bot)
 * Handle typing simulation, delay, context, dll
 */

import {
  getAllSessions,
  updateSessionStatus,
  addChatContext,
  updateStats,
  setSessionInterval,
  stopSession,
  getSession
} from './sessionManager.js';
import { generateReply, generateFollowup } from './aiEngine.js';
import {
  calculateDelay,
  shouldSkipReply,
  shouldSendDouble,
  isInActiveHours
} from './personaEngine.js';
import { addLog } from './statsTracker.js';
import { getScheduledDelay, isSleepTime } from './scheduler.js';

// Callback untuk update UI / print log
let logCallback = null;
let isRunning = false;

/**
 * Set callback untuk log output (dipanggil UI saat ada log baru)
 * @param {Function} cb - callback function(log)
 */
export function setLogCallback(cb) {
  logCallback = cb;
}

/**
 * Emit log ke callback dan simpan ke statsTracker
 * @param {string} from - phone pengirim
 * @param {string} to - phone penerima
 * @param {string} msg - isi pesan
 * @param {string} type - tipe log
 */
function emitLog(from, to, msg, type = 'message') {
  const log = addLog(from, to, msg, type);
  if (logCallback) logCallback(log);
}

/**
 * Simulasi delay typing (efek manusia lagi nulis)
 * @param {number} durationMs - berapa lama typing
 * @returns {Promise}
 */
async function simulateTyping(durationMs) {
  return new Promise(resolve => setTimeout(resolve, durationMs));
}

/**
 * Kirim satu pesan dari sesi A ke sesi B
 * Termasuk typing simulation dan delay
 * @param {Object} senderSession - sesi pengirim
 * @param {Object} receiverSession - sesi penerima
 * @returns {Promise<string|null>} pesan yang dikirim, atau null jika skip
 */
async function sendMessage(senderSession, receiverSession) {
  // Cek apakah skip reply
  if (shouldSkipReply(senderSession.persona)) {
    return null;
  }

  // Ambil context chat
  const context = senderSession.chatContext;

  // Generate pesan
  let message;
  try {
    message = await generateReply(senderSession.persona, context);
  } catch (e) {
    message = 'iya';
  }

  // Typing simulation: 2-6 detik
  const typingDuration = (Math.random() * 4000 + 2000);
  emitLog(senderSession.phone, receiverSession.phone, '', 'typing');

  // Update status jadi busy saat typing
  senderSession.status = 'busy';

  await simulateTyping(typingDuration);

  // Kirim pesan
  emitLog(senderSession.phone, receiverSession.phone, message, 'message');

  // Update context dan stats
  const chatObj = { from: senderSession.phone, to: receiverSession.phone, msg: message };
  addChatContext(senderSession.id, chatObj);
  addChatContext(receiverSession.id, chatObj);
  updateStats(senderSession.id, 'sent');
  updateStats(receiverSession.id, 'received');

  // Kembali ke status active
  senderSession.status = 'active';

  // Cek double message
  if (shouldSendDouble(senderSession.persona)) {
    const followupDelay = Math.random() * 3000 + 1000; // 1-4 detik
    await simulateTyping(followupDelay);

    const followup = generateFollowup(senderSession.persona);
    emitLog(senderSession.phone, receiverSession.phone, followup, 'message');

    const followupObj = { from: senderSession.phone, to: receiverSession.phone, msg: followup };
    addChatContext(senderSession.id, followupObj);
    addChatContext(receiverSession.id, followupObj);
    updateStats(senderSession.id, 'sent');
  }

  return message;
}

/**
 * Jalankan satu siklus percakapan antara 2 sesi random
 * @returns {Promise}
 */
async function runChatCycle() {
  if (!isRunning) return;

  // Cek waktu tidur
  if (isSleepTime()) {
    emitLog('SYSTEM', 'ALL', 'Sleep mode aktif - semua sesi offline', 'system');
    return;
  }

  // Ambil semua sesi yang tersedia
  const allSessions = getAllSessions().filter(s => s.status !== 'offline' && s.connected);

  if (allSessions.length < 2) {
    emitLog('SYSTEM', 'ALL', 'Butuh minimal 2 sesi untuk mulai warming', 'system');
    return;
  }

  // Pilih 2 sesi random yang berbeda
  const shuffled = allSessions.sort(() => Math.random() - 0.5);
  const senderSession = shuffled[0];
  const receiverSession = shuffled[1];

  // Update conversation count
  updateStats(senderSession.id, 'conversation');

  // Kirim pesan
  await sendMessage(senderSession, receiverSession);

  // Setelah pesan, kadang receiver balas balik
  if (Math.random() < 0.6 && isRunning) {
    // Delay sebelum balas
    const replyDelay = calculateDelay(receiverSession.persona);
    await new Promise(r => setTimeout(r, Math.min(replyDelay, 15000))); // max 15 detik untuk demo

    if (isRunning) {
      await sendMessage(receiverSession, senderSession);
    }
  }
}

/**
 * Start warming semua sesi
 * Loop terus dengan delay berbeda-beda
 */
export function startWarming() {
  if (isRunning) return false;
  isRunning = true;

  // Set semua sesi yang connected jadi active
  getAllSessions().forEach(s => {
    if (s.connected) {
      updateSessionStatus(s.id, 'active');
    }
  });

  emitLog('SYSTEM', 'ALL', '🔥 Warming dimulai!', 'system');

  // Loop chat simulator
  async function loop() {
    if (!isRunning) return;

    try {
      await runChatCycle();
    } catch (e) {
      emitLog('SYSTEM', 'ALL', `Error: ${e.message}`, 'system');
    }

    if (!isRunning) return;

    // Delay acak sebelum cycle berikutnya
    const delay = getScheduledDelay();
    const t = setTimeout(loop, delay);

    // Simpan timeout ke semua sesi (untuk stop)
    getAllSessions().forEach(s => {
      setSessionInterval(s.id, t);
    });
  }

  loop();
  return true;
}

/**
 * Stop warming semua sesi
 */
export function stopWarming() {
  isRunning = false;
  getAllSessions().forEach(s => {
    stopSession(s.id);
  });
  emitLog('SYSTEM', 'ALL', '⛔ Warming dihentikan', 'system');
}

/**
 * Cek apakah warming sedang berjalan
 * @returns {boolean}
 */
export function isWarmingRunning() {
  return isRunning;
}
