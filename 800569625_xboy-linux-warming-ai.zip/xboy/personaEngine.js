/**
 * personaEngine.js
 * Engine untuk generate dan manage persona setiap sesi
 * Persona mempengaruhi gaya bahasa, isi pesan, dan perilaku chat
 */

// Daftar nama persona yang bisa dipakai
const PERSONA_NAMES = [
  'Rizky', 'Fajar', 'Dani', 'Budi', 'Andi', 'Sari', 'Dewi',
  'Ayu', 'Rini', 'Hendra', 'Gilang', 'Taufik', 'Yusuf', 'Bagas',
  'Fikri', 'Nanda', 'Reza', 'Dimas', 'Wahyu', 'Agus'
];

// Gaya bahasa yang tersedia
const LANGUAGE_STYLES = ['santai', 'formal_ringan'];

// Tipe kepribadian
const PERSONALITIES = ['aktif', 'santai', 'dingin', 'sibuk'];

// Tingkat kecepatan respon
const RESPONSE_SPEEDS = ['cepat', 'normal', 'slow'];

// Warna yang tersedia untuk sesi (chalk compatible)
const SESSION_COLORS = [
  'red', 'green', 'yellow', 'blue', 'magenta', 'cyan',
  'redBright', 'greenBright', 'yellowBright', 'blueBright',
  'magentaBright', 'cyanBright'
];

/**
 * Generate persona random untuk sesi baru
 * @returns {Object} Persona object lengkap
 */
export function generatePersona() {
  const style = LANGUAGE_STYLES[Math.floor(Math.random() * LANGUAGE_STYLES.length)];
  const personality = PERSONALITIES[Math.floor(Math.random() * PERSONALITIES.length)];
  const speed = RESPONSE_SPEEDS[Math.floor(Math.random() * RESPONSE_SPEEDS.length)];
  const name = PERSONA_NAMES[Math.floor(Math.random() * PERSONA_NAMES.length)];

  return {
    name,
    style,       // santai / formal_ringan
    personality, // aktif / santai / dingin / sibuk
    speed,       // cepat / normal / slow
    // Jam aktif random (contoh: aktif jam 8 pagi - 11 malam)
    activeHours: {
      start: Math.floor(Math.random() * 4) + 7,  // 7-10 pagi
      end: Math.floor(Math.random() * 4) + 20,   // 20-23 malam
    }
  };
}

/**
 * Ambil warna unik untuk sesi berdasarkan index
 * @param {number} index - index sesi
 * @returns {string} nama warna chalk
 */
export function getSessionColor(index) {
  return SESSION_COLORS[index % SESSION_COLORS.length];
}

/**
 * Hitung delay realistis berdasarkan persona dan tipe delay
 * @param {Object} persona - persona sesi
 * @param {string} type - 'normal' | 'long'
 * @returns {number} delay dalam milidetik
 */
export function calculateDelay(persona, type = 'normal') {
  let minSec, maxSec;

  // Delay berdasarkan kecepatan respon persona
  if (persona.speed === 'cepat') {
    minSec = 5; maxSec = 20;
  } else if (persona.speed === 'normal') {
    minSec = 10; maxSec = 45;
  } else { // slow
    minSec = 30; maxSec = 120;
  }

  // Kadang delay panjang (1-5 menit)
  if (type === 'long' || Math.random() < 0.1) {
    minSec = 60; maxSec = 300;
  }

  const sec = Math.floor(Math.random() * (maxSec - minSec + 1)) + minSec;
  return sec * 1000;
}

/**
 * Cek apakah persona sedang dalam jam aktifnya
 * @param {Object} persona - persona sesi
 * @returns {boolean}
 */
export function isInActiveHours(persona) {
  const hour = new Date().getHours();
  return hour >= persona.activeHours.start && hour < persona.activeHours.end;
}

/**
 * Tentukan apakah persona skip membalas (tidak reply)
 * @param {Object} persona - persona sesi
 * @returns {boolean} true = skip
 */
export function shouldSkipReply(persona) {
  // Persona dingin lebih sering skip, aktif jarang skip
  const skipChance = {
    aktif: 0.05,
    santai: 0.15,
    dingin: 0.30,
    sibuk: 0.25
  };
  return Math.random() < (skipChance[persona.personality] || 0.1);
}

/**
 * Tentukan apakah akan kirim 2 pesan beruntun
 * @param {Object} persona - persona sesi
 * @returns {boolean}
 */
export function shouldSendDouble(persona) {
  const doubleChance = {
    aktif: 0.25,
    santai: 0.10,
    dingin: 0.05,
    sibuk: 0.08
  };
  return Math.random() < (doubleChance[persona.personality] || 0.1);
}
