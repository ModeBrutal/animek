/**
 * whatsappClient.js
 * Koneksi WhatsApp REAL menggunakan @whiskeysockets/baileys
 * Pairing code (tanpa scan QR), multi-session, auto-reconnect
 */

import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  makeCacheableSignalKeyStore,
} from '@whiskeysockets/baileys';
import { Boom }    from '@hapi/boom';
import { mkdir }   from 'fs/promises';
import { existsSync } from 'fs';
import pino        from 'pino';
import path        from 'path';
import { AUTH_DIR } from './config.js';

// Map: sessionId → socket WA
const sockets = new Map();

// Callbacks untuk log dan event
let _onLog    = null;
let _onMsg    = null;   // callback saat pesan masuk

/**
 * Set callback untuk log output
 * @param {Function} fn - fn(text, type)
 */
export function setLogCb(fn)  { _onLog = fn; }

/**
 * Set callback saat ada pesan masuk dari WA
 * @param {Function} fn - fn(sessionId, from, text)
 */
export function setMsgCb(fn)  { _onMsg = fn; }

function log(text, type = 'info') {
  if (_onLog) _onLog(text, type);
}

/**
 * Buat koneksi WhatsApp baru dan request pairing code
 * @param {string} sessionId - ID sesi
 * @param {string} phoneNumber - nomor +62xxx (tanpa +)
 * @param {Function} onPairingCode - callback(code) saat kode siap
 * @returns {Promise<Object>} socket baileys
 */
export async function connectSession(sessionId, phoneNumber, onPairingCode) {
  // Buat folder auth per sesi
  const authFolder = path.join(AUTH_DIR, sessionId);
  if (!existsSync(authFolder)) await mkdir(authFolder, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(authFolder);

  // Buat socket — matikan log pino ke console
  const sock = makeWASocket({
    auth       : state,
    printQRInTerminal: false,
    logger     : pino({ level: 'silent' }),
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: false,
  });

  sockets.set(sessionId, sock);

  // ── Handle credential save ────────────────────────
  sock.ev.on('creds.update', saveCreds);

  // ── Handle koneksi / disconnect ───────────────────
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, isNewLogin } = update;

    if (connection === 'open') {
      log(`[${sessionId}] ✅ WhatsApp terhubung!`, 'success');
    }

    if (connection === 'close') {
      const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
      if (reason === DisconnectReason.loggedOut) {
        log(`[${sessionId}] ❌ Logout — hapus folder auth untuk reconnect`, 'error');
        sockets.delete(sessionId);
      } else {
        log(`[${sessionId}] ⚠ Koneksi putus (${reason}), reconnect...`, 'warn');
        sockets.delete(sessionId);
        // Auto reconnect setelah 5 detik
        setTimeout(() => connectSession(sessionId, phoneNumber, onPairingCode), 5000);
      }
    }

    // Request pairing code saat pertama kali (belum punya credentials)
    if (isNewLogin || (!sock.authState?.creds?.registered && connection === 'connecting')) {
      // Tunggu sebentar agar socket siap
      await new Promise(r => setTimeout(r, 2000));
      try {
        // Format nomor: hilangkan +, spasi, tanda kurung
        const num = phoneNumber.replace(/[^0-9]/g, '');
        const code = await sock.requestPairingCode(num);
        log(`[${sessionId}] 📲 Pairing code: ${code}`, 'pairing');
        if (onPairingCode) onPairingCode(code);
      } catch (e) {
        log(`[${sessionId}] ⚠ Gagal request pairing code: ${e.message}`, 'warn');
      }
    }
  });

  // ── Handle pesan masuk ────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (msg.key.fromMe) continue;  // abaikan pesan dari diri sendiri
      const from = msg.key.remoteJid;
      const text = msg.message?.conversation
                || msg.message?.extendedTextMessage?.text
                || '';
      if (text && _onMsg) _onMsg(sessionId, from, text);
    }
  });

  return sock;
}

/**
 * Kirim pesan teks ke nomor tertentu
 * @param {string} sessionId - ID sesi pengirim
 * @param {string} toJid     - JID tujuan (contoh: 628xxx@s.whatsapp.net)
 * @param {string} text      - isi pesan
 * @returns {Promise<boolean>} sukses/tidak
 */
export async function sendMessage(sessionId, toJid, text) {
  const sock = sockets.get(sessionId);
  if (!sock) {
    log(`[${sessionId}] ⚠ Socket tidak ditemukan`, 'warn');
    return false;
  }
  try {
    await sock.sendMessage(toJid, { text });
    return true;
  } catch (e) {
    log(`[${sessionId}] ❌ Gagal kirim: ${e.message}`, 'error');
    return false;
  }
}

/**
 * Kirim status "typing" (composing) ke nomor tujuan
 * @param {string} sessionId
 * @param {string} toJid
 */
export async function sendTyping(sessionId, toJid) {
  const sock = sockets.get(sessionId);
  if (!sock) return;
  try {
    await sock.sendPresenceUpdate('composing', toJid);
    // Pause composing setelah beberapa detik
    await new Promise(r => setTimeout(r, 3000 + Math.random() * 3000));
    await sock.sendPresenceUpdate('paused', toJid);
  } catch (_) {}
}

/**
 * Cek apakah sesi sudah connected
 * @param {string} sessionId
 * @returns {boolean}
 */
export function isConnected(sessionId) {
  const sock = sockets.get(sessionId);
  return !!(sock?.user);
}

/**
 * Ambil JID dari nomor HP
 * @param {string} phone - format 628xxx
 * @returns {string} JID
 */
export function toJid(phone) {
  return `${phone.replace(/[^0-9]/g, '')}@s.whatsapp.net`;
}

/**
 * Disconnect sesi
 * @param {string} sessionId
 */
export async function disconnectSession(sessionId) {
  const sock = sockets.get(sessionId);
  if (sock) {
    try { await sock.logout(); } catch (_) {}
    sockets.delete(sessionId);
  }
}

/**
 * Ambil semua sessionId yang terkoneksi
 * @returns {string[]}
 */
export function getConnectedIds() {
  return [...sockets.keys()].filter(id => isConnected(id));
}
