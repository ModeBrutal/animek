/**
 * aiEngine.js
 * Hybrid AI: 30% Gemini, 70% random message bank
 * Mendukung input API key manual dari CLI
 */

import { CHANCE } from './config.js';

// ── State ─────────────────────────────────────────────
let _apiKey    = null;
let _geminiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

// ── Message Banks ──────────────────────────────────────
const GREET   = ['hei','hai','halo','hey','woi','oi','yo','haloo','bro','sis'];
const CASUAL  = [
  'iya bro','oh oke','wkwk iya','bener juga sih','hahaha',
  'serius?','masa sih','anjir beneran','wkwkwk','iya nih',
  'nah itu dia','bisa juga','hmm iya deh','lah kok gitu',
  'emg gitu','ya emang','bener banget','lol','haha iya',
  'oh ternyata','gitu ya','mantap','okesip','sip bro',
  'gaskeun','parah banget','buset','yaelah','ih iya jg',
];
const FORMAL  = [
  'iya memang begitu','betul sekali','aku setuju','oh begitu ya',
  'hmm menarik','aku pikir juga begitu','ya kamu benar',
  'memang iya sih','bisa jadi','aku rasa iya',
  'sip terima kasih','noted ya','oke siap','aku paham',
  'baik aku mengerti','tentu saja','oke deh','bisa aku pahami',
];
const TOPICS  = [
  'btw lu udah makan belom?','eh ngomong2 gimana kabar?',
  'btw itu gimana ceritanya?','lu lagi ngapain sekarang?',
  'aku lagi males banget nih','kemarin aku liat yg aneh banget',
  'wah serius itu?','emang gitu sih','btw jadi gimana?',
  'kok bisa gitu ya','aku juga heran','nanti aja deh',
  'aku lagi sibuk btw','besok aja ya','ntar gue kabarin',
  'iya deh nanti ku pikirin','gaskeun aja lah','btw udh tau blm?',
  'kemarin diajak tp ga bisa','sok sibuk lu wkwk','aduh males',
  'eh iya beneran tuh?','serius deh kayanya','tau ah males',
  'ya gitu deh','ya udah sih','mau gimana lagi',
];
const FOLLOWUP= ['eh iya btw','lupa bilang','oh iya satu lagi','btw','nah ini dia','wait','eh','tambahan nih'];
const EMOJIS  = ['😂','😏','🔥','😅','😭','👍','😄','🤣','💀','😩','🫠','😆'];

const TYPO_MAP = {
  'yang':'yg','dengan':'dgn','tidak':'ga','sudah':'udah',
  'belum':'blom','sama':'sm','karena':'krna','juga':'jg',
  'kalau':'klo','itu':'tuh','ini':'ni','bisa':'bsa',
  'untuk':'utk','dari':'dr','tapi':'tp','nanti':'ntr',
  'memang':'emang','sudah':'udh','makan':'mkn',
};

// ── Helpers ───────────────────────────────────────────

/** Tambah typo/singkatan random */
function applyTypo(text) {
  if (Math.random() > CHANCE.ADD_TYPO) return text;
  let r = text;
  for (const [w, t] of Object.entries(TYPO_MAP)) {
    if (r.includes(w) && Math.random() > 0.5) r = r.replace(w, t);
  }
  return r;
}

/** Tambah emoji random (max 1) */
function applyEmoji(text) {
  if (Math.random() > CHANCE.ADD_EMOJI) return text;
  return `${text} ${EMOJIS[Math.floor(Math.random() * EMOJIS.length)]}`;
}

/** Pilih random dari array */
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

// ── Public API ────────────────────────────────────────

/**
 * Simpan API key Gemini ke memory
 * @param {string} key
 */
export function setApiKey(key) { _apiKey = key.trim(); }

/**
 * Cek apakah API key sudah diset
 * @returns {boolean}
 */
export function hasApiKey() { return !!_apiKey && _apiKey.length > 10; }

/**
 * Generate random message dari pool sesuai persona
 * @param {Object} persona
 * @returns {string}
 */
function randomMsg(persona) {
  const pool   = persona.style === 'santai' ? CASUAL : FORMAL;
  const rand   = Math.random();
  let msg;

  if      (rand < 0.40) msg = pick(pool);
  else if (rand < 0.70) msg = pick(TOPICS);
  else if (rand < 0.85) msg = `${pick(GREET)}, ${pick(TOPICS)}`;
  else                  msg = pick(GREET);

  return applyEmoji(applyTypo(msg));
}

/**
 * Generate reply via Gemini API
 * @param {Object} persona
 * @param {Array}  ctx - chat context terakhir
 * @returns {Promise<string>}
 */
async function aiMsg(persona, ctx = []) {
  const { default: fetch } = await import('node-fetch');
  const ctxStr = ctx.slice(-3).map(c => `${c.from}: ${c.msg}`).join('\n');

  const prompt = `Kamu adalah ${persona.name}, orangnya ${persona.personality === 'aktif' ? 'ceria & aktif' : persona.personality === 'dingin' ? 'cuek & singkat' : persona.personality === 'sibuk' ? 'sibuk & singkat' : 'santai & asik'}.
Gaya bahasa: ${persona.style === 'santai' ? 'pakai gw/lu, gaul, boleh typo' : 'pakai aku/kamu, agak formal tapi tetap santai'}.
Context:\n${ctxStr || '(awal chat)'}
Balas SATU kalimat pendek (max 12 kata), natural seperti chat WA biasa. Boleh emoji max 1.`;

  const res  = await fetch(`${_geminiUrl}?key=${_apiKey}`, {
    method  : 'POST',
    headers : { 'Content-Type': 'application/json' },
    body    : JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });
  const json = await res.json();
  const text = json?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ?? null;
  if (!text) throw new Error('Empty AI response');
  return text.split('\n')[0].substring(0, 120);
}

/**
 * Main: generate reply hybrid (30% AI / 70% random)
 * @param {Object} persona
 * @param {Array}  ctx
 * @returns {Promise<string>}
 */
export async function generateReply(persona, ctx = []) {
  if (hasApiKey() && Math.random() < CHANCE.USE_AI) {
    try { return applyEmoji(applyTypo(await aiMsg(persona, ctx))); } catch (_) {}
  }
  return randomMsg(persona);
}

/**
 * Generate pesan followup (double message)
 * @param {Object} persona
 * @returns {string}
 */
export function generateFollowup(persona) {
  return applyEmoji(`${pick(FOLLOWUP)} ${pick(TOPICS)}`);
}
