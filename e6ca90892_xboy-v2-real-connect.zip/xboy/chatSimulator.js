/**
 * chatSimulator.js
 * Orchestrator warming: loop chat antar sesi WA nyata
 */

import { getAllSessions, setStatus, pushContext, bumpStat, setTimer, stopSession } from './sessionManager.js';
import { generateReply, generateFollowup }       from './aiEngine.js';
import { shouldSkip, shouldDouble, calcDelay }   from './personaEngine.js';
import { sendMessage, sendTyping, toJid, isConnected } from './whatsappClient.js';
import { addLog }     from './statsTracker.js';
import { cycleDelay, isSleepTime, tick } from './scheduler.js';
import { DELAY }      from './config.js';

let _running  = false;
let _logCb    = null;
let _loopTimer= null;

/**
 * Set callback log ke UI
 * @param {Function} fn - fn(log)
 */
export function setLogCb(fn) { _logCb = fn; }

/**
 * Emit log ke tracker + UI
 */
function emit(from, to, msg, type = 'message') {
  const log = addLog(from, to, msg, type);
  if (_logCb) _logCb(log);
}

/**
 * Satu siklus chat: pilih 2 sesi random, saling kirim pesan
 */
async function runCycle() {
  if (!_running) return;
  if (isSleepTime()) { emit('SYSTEM','ALL','😴 Sleep mode — semua sesi istirahat','system'); return; }

  tick(); // update jadwal aktivitas

  const active = getAllSessions().filter(s => s.connected && isConnected(s.id));
  if (active.length < 2) {
    emit('SYSTEM','ALL','⚠ Butuh minimal 2 sesi connected untuk warming','system');
    return;
  }

  // Pilih 2 sesi acak
  const shuffled = active.sort(() => Math.random() - 0.5);
  const A = shuffled[0];
  const B = shuffled[1];

  bumpStat(A.id, 'conversation');

  // A kirim ke B
  await doSend(A, B);

  // Kadang B balas balik
  if (_running && Math.random() < 0.60) {
    const replyDelay = Math.min(calcDelay(B.persona), 15000);
    await sleep(replyDelay);
    if (_running) await doSend(B, A);
  }
}

/**
 * Satu aksi kirim pesan dari sender ke receiver
 * @param {Object} sender   - sesi pengirim
 * @param {Object} receiver - sesi penerima
 */
async function doSend(sender, receiver) {
  if (shouldSkip(sender.persona)) {
    emit(sender.phone, receiver.phone, '(skip reply)', 'system');
    return;
  }

  const ctx = sender.chatContext;
  let   msg;
  try   { msg = await generateReply(sender.persona, ctx); }
  catch { msg = 'iya'; }

  // Typing simulation
  emit(sender.phone, receiver.phone, '', 'typing');
  setStatus(sender.id, 'busy');
  const jidB = toJid(receiver.phone);
  await sendTyping(sender.id, jidB);
  await sleep(rand(DELAY.TYPING_MIN, DELAY.TYPING_MAX));

  // Kirim pesan nyata via WA
  const ok = await sendMessage(sender.id, jidB, msg);
  if (ok) {
    emit(sender.phone, receiver.phone, msg, 'message');
    pushContext(sender.id,   { from: sender.phone,   msg });
    pushContext(receiver.id, { from: sender.phone,   msg });
    bumpStat(sender.id,   'sent');
    bumpStat(receiver.id, 'received');
  }
  setStatus(sender.id, 'active');

  // Double message
  if (shouldDouble(sender.persona) && ok) {
    await sleep(rand(DELAY.DOUBLE_MIN, DELAY.DOUBLE_MAX));
    const extra = generateFollowup(sender.persona);
    const ok2   = await sendMessage(sender.id, jidB, extra);
    if (ok2) {
      emit(sender.phone, receiver.phone, extra, 'message');
      bumpStat(sender.id, 'sent');
    }
  }
}

/**
 * Mulai warming loop
 * @returns {boolean} apakah berhasil start
 */
export function startWarming() {
  if (_running) return false;
  _running = true;
  emit('SYSTEM','ALL','🔥 Warming dimulai!','system');
  scheduleLoop();
  return true;
}

/**
 * Stop warming loop
 */
export function stopWarming() {
  _running = false;
  if (_loopTimer) { clearTimeout(_loopTimer); _loopTimer = null; }
  getAllSessions().forEach(s => stopSession(s.id));
  emit('SYSTEM','ALL','⛔ Warming dihentikan','system');
}

/**
 * Cek apakah warming berjalan
 * @returns {boolean}
 */
export function isRunning() { return _running; }

/** Jadwalkan cycle berikutnya */
function scheduleLoop() {
  if (!_running) return;
  _loopTimer = setTimeout(async () => {
    try   { await runCycle(); }
    catch (e) { emit('SYSTEM','ALL',`Error: ${e.message}`,'system'); }
    scheduleLoop();
  }, cycleDelay());
}

// ── helpers ───────────────────────────────────────────
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function rand(a,b) { return Math.floor(Math.random()*(b-a+1))+a; }
