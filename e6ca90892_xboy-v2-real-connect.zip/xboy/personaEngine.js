/**
 * personaEngine.js
 * Generate persona unik per sesi: gaya bahasa, kepribadian, kecepatan respon
 */

import { DELAY, CHANCE } from './config.js';

const NAMES = [
  'Rizky','Fajar','Dani','Budi','Andi','Sari','Dewi','Ayu',
  'Rini','Hendra','Gilang','Taufik','Yusuf','Bagas','Fikri',
  'Nanda','Reza','Dimas','Wahyu','Agus','Putri','Lila','Vina'
];

const COLORS = [
  'red','green','yellow','blue','magenta','cyan',
  'redBright','greenBright','yellowBright','blueBright','magentaBright','cyanBright'
];

let colorIdx = 0;

/**
 * Buat persona baru secara acak
 * @returns {Object} persona lengkap
 */
export function generatePersona() {
  const styles       = ['santai', 'formal_ringan'];
  const personalities= ['aktif', 'santai', 'dingin', 'sibuk'];
  const speeds       = ['cepat', 'normal', 'slow'];

  return {
    name        : NAMES[Math.floor(Math.random() * NAMES.length)],
    style       : styles[Math.floor(Math.random() * styles.length)],
    personality : personalities[Math.floor(Math.random() * personalities.length)],
    speed       : speeds[Math.floor(Math.random() * speeds.length)],
    activeHours : {
      start : Math.floor(Math.random() * 4) + 7,   // 7-10
      end   : Math.floor(Math.random() * 4) + 20,  // 20-23
    },
  };
}

/**
 * Ambil warna chalk unik per sesi
 * @returns {string}
 */
export function nextColor() {
  return COLORS[colorIdx++ % COLORS.length];
}

/**
 * Hitung delay realistis berdasarkan persona
 * @param {Object} persona
 * @param {'normal'|'long'} type
 * @returns {number} ms
 */
export function calcDelay(persona, type = 'normal') {
  if (type === 'long' || Math.random() < CHANCE.LONG_DELAY) {
    return rand(DELAY.LONG_MIN, DELAY.LONG_MAX);
  }
  const map = {
    cepat  : [DELAY.REPLY_MIN, 20000],
    normal : [DELAY.REPLY_MIN, DELAY.REPLY_MAX],
    slow   : [30000, DELAY.LONG_MIN],
  };
  const [min, max] = map[persona.speed] || map.normal;
  return rand(min, max);
}

/**
 * Apakah sesi skip balas?
 * @param {Object} persona
 * @returns {boolean}
 */
export function shouldSkip(persona) {
  const c = { aktif:0.05, santai:0.15, dingin:0.30, sibuk:0.25 };
  return Math.random() < (c[persona.personality] ?? CHANCE.SKIP_REPLY);
}

/**
 * Apakah kirim pesan kedua beruntun?
 * @param {Object} persona
 * @returns {boolean}
 */
export function shouldDouble(persona) {
  const c = { aktif:0.25, santai:0.10, dingin:0.05, sibuk:0.08 };
  return Math.random() < (c[persona.personality] ?? CHANCE.DOUBLE_MSG);
}

/**
 * Apakah dalam jam aktif?
 * @param {Object} persona
 * @returns {boolean}
 */
export function inActiveHours(persona) {
  const h = new Date().getHours();
  return h >= persona.activeHours.start && h < persona.activeHours.end;
}

// ── helper ────────────────────────────────────────────
function rand(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
