/**
 * config.js
 * Konfigurasi global aplikasi X'Boy Warming AI Pro
 */

export const APP_VERSION = '2.0.0';
export const APP_NAME    = "X'Boy Warming AI Pro";

// ── Delay realistis (dalam ms) ─────────────────────────
export const DELAY = {
  TYPING_MIN  : 2000,
  TYPING_MAX  : 6000,
  REPLY_MIN   : 8000,
  REPLY_MAX   : 45000,
  LONG_MIN    : 60000,
  LONG_MAX    : 300000,
  DOUBLE_MIN  : 1000,
  DOUBLE_MAX  : 4000,
};

// ── Peluang perilaku ───────────────────────────────────
export const CHANCE = {
  LONG_DELAY  : 0.10,   // 10% delay panjang 1-5 menit
  DOUBLE_MSG  : 0.15,   // 15% kirim 2 pesan beruntun
  SKIP_REPLY  : 0.12,   // 12% tidak membalas
  ADD_EMOJI   : 0.30,   // 30% tambah emoji
  ADD_TYPO    : 0.20,   // 20% ada typo/singkatan
  USE_AI      : 0.30,   // 30% pakai AI, 70% random
};

// ── Scheduler ─────────────────────────────────────────
export const SCHEDULE = {
  pagi         : { label:'🌅 Pagi',       activeChance: 0.30, minSec: 60,  maxSec: 180 },
  siang        : { label:'☀️  Siang',      activeChance: 0.60, minSec: 30,  maxSec: 90  },
  malam        : { label:'🌙 Malam',       activeChance: 0.85, minSec: 10,  maxSec: 45  },
  tengah_malam : { label:'😴 Tengah Malam',activeChance: 0.05, minSec: 300, maxSec: 600 },
};

// ── Direktori auth sesi ────────────────────────────────
export const AUTH_DIR = './sessions';
