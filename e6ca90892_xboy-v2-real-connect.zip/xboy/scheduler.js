/**
 * scheduler.js
 * Auto activity scheduler berdasarkan periode waktu
 */

import { SCHEDULE } from './config.js';
import { getAllSessions, setStatus } from './sessionManager.js';

/**
 * Ambil periode waktu sekarang
 * @returns {'pagi'|'siang'|'malam'|'tengah_malam'}
 */
export function getTimePeriod() {
  const h = new Date().getHours();
  if (h >= 5  && h < 11) return 'pagi';
  if (h >= 11 && h < 17) return 'siang';
  if (h >= 17 && h < 23) return 'malam';
  return 'tengah_malam';
}

/**
 * Ambil config aktivitas berdasarkan periode
 * @param {string} period
 * @returns {Object}
 */
export function getActivity(period) {
  return SCHEDULE[period] ?? SCHEDULE.siang;
}

/**
 * Update status semua sesi sesuai jadwal
 */
export function tick() {
  const period   = getTimePeriod();
  const activity = getActivity(period);
  getAllSessions().forEach(s => {
    if (!s.connected || s.status === 'busy') return;
    const r = Math.random();
    if      (r < activity.activeChance)        setStatus(s.id, 'active');
    else if (r < activity.activeChance + 0.1)  setStatus(s.id, 'offline');
    else                                        setStatus(s.id, 'idle');
  });
  return { period, activity };
}

/**
 * Hitung delay cycle berdasarkan jadwal
 * @returns {number} ms
 */
export function cycleDelay() {
  const a = getActivity(getTimePeriod());
  const sec = Math.floor(Math.random() * (a.maxSec - a.minSec + 1)) + a.minSec;
  return sec * 1000;
}

/**
 * Cek apakah waktu tidur
 * @returns {boolean}
 */
export function isSleepTime() { return getTimePeriod() === 'tengah_malam'; }
