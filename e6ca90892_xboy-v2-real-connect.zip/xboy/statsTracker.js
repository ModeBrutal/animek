/**
 * statsTracker.js
 * Global chat log + statistik ringkasan
 */

const logs    = [];
const MAX_LOG = 300;

/**
 * Tambah log baru
 * @param {string} from
 * @param {string} to
 * @param {string} message
 * @param {'message'|'typing'|'system'|'pairing'} type
 * @returns {Object} log entry
 */
export function addLog(from, to, message, type = 'message') {
  const now = new Date();
  const entry = {
    time      : now.toTimeString().slice(0,8),
    timestamp : now,
    from, to, message, type,
  };
  logs.push(entry);
  if (logs.length > MAX_LOG) logs.shift();
  return entry;
}

/**
 * Ambil log terbaru
 * @param {number} n
 * @returns {Object[]}
 */
export function getLatestLogs(n = 50) { return logs.slice(-n); }

/**
 * Clear semua log
 */
export function clearLogs() { logs.length = 0; }
