/**
 * sessionManager.js
 * Manage semua sesi warming: create, delete, stats, context
 */

import { generatePersona, nextColor } from './personaEngine.js';

/** @type {Map<string, Object>} */
const sessions = new Map();

/**
 * Buat sesi baru
 * @param {string} phone - nomor HP +62xxx
 * @returns {Object} sesi
 */
export function createSession(phone) {
  const id = `sess_${Date.now()}_${Math.floor(Math.random()*1000)}`;
  const session = {
    id,
    phone,
    persona     : generatePersona(),
    color       : nextColor(),
    status      : 'connecting',   // connecting | idle | active | busy | offline
    pairingCode : null,
    connected   : false,
    stats       : { sent: 0, received: 0, conversations: 0, lastActive: null },
    chatContext : [],
    chatTimer   : null,
    createdAt   : new Date(),
  };
  sessions.set(id, session);
  return session;
}

/**
 * Ambil sesi by ID
 * @param {string} id
 * @returns {Object|null}
 */
export function getSession(id)        { return sessions.get(id) ?? null; }

/**
 * Ambil semua sesi
 * @returns {Object[]}
 */
export function getAllSessions()      { return [...sessions.values()]; }

/**
 * Update status sesi
 * @param {string} id
 * @param {string} status
 */
export function setStatus(id, status) {
  const s = sessions.get(id);
  if (s) { s.status = status; s.stats.lastActive = new Date(); }
}

/**
 * Tandai sesi sudah connected
 * @param {string} id
 * @param {string} code - pairing code
 */
export function setConnected(id, code = null) {
  const s = sessions.get(id);
  if (s) { s.connected = true; s.pairingCode = code; s.status = 'idle'; }
}

/**
 * Tambah pesan ke context (max 3)
 * @param {string} id
 * @param {Object} msg - {from, msg}
 */
export function pushContext(id, msg) {
  const s = sessions.get(id);
  if (!s) return;
  s.chatContext.push(msg);
  if (s.chatContext.length > 3) s.chatContext.shift();
}

/**
 * Update statistik
 * @param {string} id
 * @param {'sent'|'received'|'conversation'} type
 */
export function bumpStat(id, type) {
  const s = sessions.get(id);
  if (!s) return;
  if (type === 'sent')         s.stats.sent++;
  if (type === 'received')     s.stats.received++;
  if (type === 'conversation') s.stats.conversations++;
  s.stats.lastActive = new Date();
}

/**
 * Simpan timer sesi (untuk di-clear saat stop)
 * @param {string} id
 * @param {any}    timer
 */
export function setTimer(id, timer) {
  const s = sessions.get(id);
  if (s) s.chatTimer = timer;
}

/**
 * Stop sesi (clear timer, set idle)
 * @param {string} id
 */
export function stopSession(id) {
  const s = sessions.get(id);
  if (!s) return;
  if (s.chatTimer) { clearTimeout(s.chatTimer); s.chatTimer = null; }
  s.status = 'idle';
}

/**
 * Stop semua sesi
 */
export function stopAll() { sessions.forEach((_, id) => stopSession(id)); }

/**
 * Hapus sesi
 * @param {string} id
 */
export function deleteSession(id) { stopSession(id); sessions.delete(id); }

/**
 * Statistik global
 * @returns {Object}
 */
export function globalStats() {
  const all = [...sessions.values()];
  return {
    total        : all.length,
    connected    : all.filter(s => s.connected).length,
    active       : all.filter(s => s.status === 'active').length,
    idle         : all.filter(s => s.status === 'idle').length,
    offline      : all.filter(s => s.status === 'offline').length,
    busy         : all.filter(s => s.status === 'busy').length,
    connecting   : all.filter(s => s.status === 'connecting').length,
    totalSent    : all.reduce((s, x) => s + x.stats.sent, 0),
    totalRecv    : all.reduce((s, x) => s + x.stats.received, 0),
    totalConvs   : all.reduce((s, x) => s + x.stats.conversations, 0),
  };
}
