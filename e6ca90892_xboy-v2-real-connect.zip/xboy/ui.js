/**
 * ui.js
 * Terminal UI modern: chalk, boxen, inquirer, cli-table3
 */

import chalk     from 'chalk';
import inquirer  from 'inquirer';
import Table     from 'cli-table3';
import boxen     from 'boxen';

// ── Palette modern ────────────────────────────────────
const C = {
  title    : chalk.hex('#00E5FF').bold,
  sub      : chalk.hex('#64B5F6'),
  success  : chalk.hex('#69F0AE').bold,
  warn     : chalk.hex('#FFD740'),
  error    : chalk.hex('#FF5252'),
  dim      : chalk.hex('#546E7A'),
  white    : chalk.hex('#ECEFF1'),
  running  : chalk.bgHex('#00C853').hex('#000000').bold,
  stopped  : chalk.bgHex('#D50000').hex('#FFFFFF').bold,
  pairing  : chalk.bgHex('#FF6D00').hex('#FFFFFF').bold,
};

// ── ASCII Banner ──────────────────────────────────────
const BANNER = `
 ██╗  ██╗ ██████╗  ██████╗ ██╗   ██╗
 ╚██╗██╔╝ ██╔══██╗██╔═══██╗╚██╗ ██╔╝
  ╚███╔╝  ██████╔╝██║   ██║ ╚████╔╝ 
  ██╔██╗  ██╔══██╗██║   ██║  ╚██╔╝  
 ██╔╝ ██╗ ██████╔╝╚██████╔╝   ██║   
 ╚═╝  ╚═╝ ╚═════╝  ╚═════╝    ╚═╝   `;

/**
 * Print header aplikasi
 */
export function printHeader() {
  console.clear();
  console.log(C.title(BANNER));
  console.log(C.sub('  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'));
  console.log(C.sub('   Warming AI Pro v2.0  |  Real WhatsApp Connect'));
  console.log(C.dim('  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n'));
}

/**
 * Print dashboard utama
 * @param {Object}  stats     - global stats
 * @param {string}  period    - periode waktu
 * @param {boolean} running   - warming aktif?
 * @param {boolean} apiReady  - AI key siap?
 */
export function printDashboard(stats, period, running, apiReady) {
  const wStatus = running ? C.running(' ● RUNNING ') : C.stopped(' ■ STOPPED ');
  const aStatus = apiReady ? C.success('✔ AI Connected') : C.warn('✘ No API Key (random mode)');

  const left = [
    `  ${C.white('Warming')}   ${wStatus}`,
    `  ${C.white('Gemini AI')} ${aStatus}`,
    `  ${C.white('Waktu')}     ${C.title(period)}`,
    ``,
    `  ${C.sub('─── Sesi ───────────────')}`,
    `  ${C.white('Total')}       ${chalk.yellow(stats.total)}`,
    `  ${C.white('Connected')}   ${chalk.greenBright(stats.connected)}`,
    `  ${C.white('Active')}      ${chalk.green(stats.active)}`,
    `  ${C.white('Idle')}        ${chalk.blue(stats.idle)}`,
    `  ${C.white('Offline')}     ${chalk.gray(stats.offline)}`,
    `  ${C.white('Connecting')}  ${chalk.cyan(stats.connecting)}`,
  ].join('\n');

  const right = [
    `  ${C.sub('─── Chat ───────────────')}`,
    `  ${C.white('Total Terkirim')}   ${chalk.green(stats.totalSent)}`,
    `  ${C.white('Total Diterima')}   ${chalk.cyan(stats.totalRecv)}`,
    `  ${C.white('Total Percakpn')}   ${chalk.yellow(stats.totalConvs)}`,
  ].join('\n');

  const content = left + '\n\n' + right;

  console.log(boxen(content, {
    padding       : 1,
    borderStyle   : 'round',
    borderColor   : '#00E5FF',
    title         : " 📊 Dashboard ",
    titleAlignment: 'center',
  }));
  console.log('');
}

/**
 * Print list sesi
 * @param {Object[]} sessions
 */
export function printSessionList(sessions) {
  if (!sessions.length) {
    console.log(C.warn('  ⚠  Belum ada sesi. Pilih menu 1 untuk tambah sesi.\n'));
    return;
  }

  const t = new Table({
    head : ['#', 'Phone', 'Nama', 'Status', 'Connected', 'Style', 'Sent', 'Recv'].map(h => C.sub(h)),
    style: { border:['dim'], head:[] },
    colWidths: [4, 16, 10, 12, 11, 16, 7, 7],
  });

  const STATUS_COLOR = { active:'greenBright', idle:'blue', offline:'gray', busy:'magenta', connecting:'cyan' };

  sessions.forEach((s, i) => {
    const sc   = STATUS_COLOR[s.status] ?? 'white';
    t.push([
      chalk[s.color](`${i+1}`),
      chalk[s.color](s.phone),
      chalk[s.color](s.persona.name),
      chalk[sc](s.status),
      s.connected ? C.success('✔') : C.error('✘'),
      s.persona.style,
      chalk.green(s.stats.sent),
      chalk.cyan(s.stats.received),
    ]);
  });
  console.log(t.toString() + '\n');
}

/**
 * Print log chat ke terminal
 * @param {Object[]} logs
 * @param {Object[]} sessions
 */
export function printLogs(logs, sessions) {
  const cmap = {};
  sessions.forEach(s => { cmap[s.phone] = s.color; });

  if (!logs.length) { console.log(C.dim('  Belum ada log.\n')); return; }

  logs.slice(-35).forEach(l => {
    const time = C.dim(`[${l.time}]`);
    if (l.type === 'system') {
      console.log(`${time} ${chalk.bgBlue.white(' SYS ')} ${C.sub(l.message)}`);
    } else if (l.type === 'pairing') {
      console.log(`${time} ${C.pairing(' PAIR ')} ${C.warn(l.message)}`);
    } else if (l.type === 'typing') {
      const fc = cmap[l.from] ?? 'white';
      console.log(`${time} ${chalk[fc](l.from)} ${C.dim('is typing...')}`);
    } else {
      const fc = cmap[l.from] ?? 'white';
      const tc = cmap[l.to]   ?? 'white';
      console.log(`${time} ${chalk[fc](l.from)} ${C.dim('→')} ${chalk[tc](l.to)} ${C.dim(':')} ${C.white(l.message)}`);
    }
  });
  console.log('');
}

/**
 * Print statistik per sesi
 * @param {Object[]} sessions
 */
export function printStats(sessions) {
  if (!sessions.length) { console.log(C.warn('  Belum ada sesi.\n')); return; }
  sessions.forEach(s => {
    const last = s.stats.lastActive ? new Date(s.stats.lastActive).toLocaleTimeString('id-ID') : '-';
    const lines = [
      `  ${chalk[s.color].bold(s.persona.name)}  ${C.dim(s.phone)}`,
      `  Status     : ${s.status}   Connected: ${s.connected ? '✔':'✘'}`,
      `  Personality: ${s.persona.personality}   Style: ${s.persona.style}   Speed: ${s.persona.speed}`,
      `  Jam Aktif  : ${s.persona.activeHours.start}:00 – ${s.persona.activeHours.end}:00`,
      `  Sent/Recv  : ${chalk.green(s.stats.sent)} / ${chalk.cyan(s.stats.received)}   Convs: ${chalk.yellow(s.stats.conversations)}`,
      `  Last Active: ${C.dim(last)}`,
    ].join('\n');
    console.log(boxen(lines, { padding:{top:0,bottom:0,left:0,right:1}, borderStyle:'single', borderColor: s.color }));
    console.log('');
  });
}

/**
 * Menu utama
 * @param {boolean} running
 * @returns {Promise<string>}
 */
export async function mainMenu(running) {
  const { c } = await inquirer.prompt([{
    type   : 'list',
    name   : 'c',
    message: C.title('Pilih menu:'),
    prefix : '▶',
    choices: [
      { name: `${chalk.green('1.')} Tambah Sesi (Hubungkan WhatsApp)`, value:'1' },
      {
        name : running
          ? `${C.dim('2.')} ${C.dim('Mulai Warming')} ${C.warn('(sudah running)')}`
          : `${chalk.green('2.')} Mulai Warming`,
        value: '2',
        disabled: running ? '(sudah running)' : false,
      },
      {
        name: running
          ? `${chalk.green('3.')} ${C.error('Stop Warming')} ${C.running(' RUNNING ')}`
          : `${C.dim('3.')} ${C.dim('Stop Warming')} (tidak aktif)`,
        value:'3',
      },
      { name:`${chalk.green('4.')} Set API Key (Gemini AI)`, value:'4' },
      { name:`${chalk.green('5.')} Statistik Per Sesi`,      value:'5' },
      { name:`${chalk.green('6.')} Log Chat`,                value:'6' },
      { name:`${chalk.green('7.')} Daftar Sesi`,             value:'7' },
      new inquirer.Separator(C.dim('─────────────────────────')),
      { name:`${C.error('8.')} Keluar`, value:'8' },
    ],
  }]);
  return c;
}

/**
 * Prompt nomor HP untuk sesi baru
 * @returns {Promise<string>} nomor HP
 */
export async function promptPhone() {
  const { phone } = await inquirer.prompt([{
    type    : 'input',
    name    : 'phone',
    message : C.title('Nomor HP (contoh: 628123456789):'),
    prefix  : '📱',
    validate: v => /^62[0-9]{9,13}$/.test(v.replace(/\s/g,'')) || 'Format: 628xxx (tanpa +)',
    filter  : v => v.replace(/[\s\-+]/g, ''),
  }]);
  return phone;
}

/**
 * Prompt API key
 * @returns {Promise<string>}
 */
export async function promptApiKey() {
  const { k } = await inquirer.prompt([{
    type   : 'password',
    name   : 'k',
    message: C.title('Masukkan Gemini API Key:'),
    prefix : '🔑',
    mask   : '•',
  }]);
  return k;
}

/**
 * Prompt konfirmasi
 * @param {string} msg
 * @returns {Promise<boolean>}
 */
export async function confirm(msg) {
  const { ok } = await inquirer.prompt([{
    type   : 'confirm',
    name   : 'ok',
    message: C.warn(msg),
    default: false,
    prefix : '⚠',
  }]);
  return ok;
}

/** Helpers pesan */
export const ok  = msg => console.log(C.success(`\n  ✅ ${msg}\n`));
export const err = msg => console.log(C.error(`\n  ❌ ${msg}\n`));
export const info= msg => console.log(C.sub(`\n  ℹ  ${msg}\n`));
export const warn= msg => console.log(C.warn(`\n  ⚠  ${msg}\n`));

/** Tunggu Enter */
export async function pressEnter() {
  await inquirer.prompt([{ type:'input', name:'_', message: C.dim('Tekan Enter untuk lanjut...'), prefix:'' }]);
}
