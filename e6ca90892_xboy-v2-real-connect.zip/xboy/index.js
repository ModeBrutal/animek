/**
 * index.js  —  X'Boy Warming AI Pro v2.0
 * Entry point: main loop, menu, orchestration
 * Koneksi WhatsApp REAL via @whiskeysockets/baileys + pairing code
 */

import chalk  from 'chalk';
import ora    from 'ora';
import { mkdir } from 'fs/promises';

import { createSession, getAllSessions, globalStats, setConnected } from './sessionManager.js';
import { startWarming, stopWarming, isRunning, setLogCb }         from './chatSimulator.js';
import { setApiKey, hasApiKey }                                    from './aiEngine.js';
import { connectSession, setLogCb as waLog, setMsgCb, disconnectSession } from './whatsappClient.js';
import { getTimePeriod, tick }                                     from './scheduler.js';
import { getLatestLogs }                                           from './statsTracker.js';
import { addLog }                                                  from './statsTracker.js';
import {
  printHeader, printDashboard, printSessionList,
  printLogs, printStats, mainMenu,
  promptPhone, promptApiKey, confirm,
  ok, err, info, warn, pressEnter,
} from './ui.js';

// ── Setup log callbacks ───────────────────────────────

/** Live log buffer untuk tampilan */
const liveLog = [];

/** Terima log dari chatSimulator */
setLogCb(log => {
  liveLog.push(log);
  if (liveLog.length > 150) liveLog.shift();
});

/** Terima log dari whatsappClient */
waLog((text, type) => {
  const log = addLog('WA', 'SYS', text, type === 'pairing' ? 'pairing' : 'system');
  liveLog.push(log);
  if (liveLog.length > 150) liveLog.shift();

  // Deteksi koneksi berhasil dan update sesi
  if (type === 'success') {
    const match = text.match(/\[(sess_[^\]]+)\]/);
    if (match) setConnected(match[1]);
  }
});

/** Terima pesan WA masuk — log ke tracker */
setMsgCb((sessionId, from, text) => {
  const log = addLog(from, sessionId, text, 'message');
  liveLog.push(log);
  if (liveLog.length > 150) liveLog.shift();
});

// ── Pastikan folder sessions ada ─────────────────────
await mkdir('./sessions', { recursive: true });

// ── Handler menu ──────────────────────────────────────

/**
 * 1. Tambah sesi + hubungkan ke WhatsApp real
 */
async function handleAddSession() {
  printHeader();
  info('Tambah Sesi & Hubungkan WhatsApp\n');
  console.log(chalk.hex('#64B5F6')([
    '  Cara pairing:',
    '  1. Buka WhatsApp di HP kamu',
    '  2. Ketuk ⋮ (titik tiga) → Perangkat Tertaut',
    '  3. Ketuk "Tautkan Perangkat"',
    '  4. Pilih "Tautkan dengan nomor telepon"',
    '  5. Masukkan kode 8 karakter yang akan muncul di sini\n',
  ].join('\n')));

  const phone = await promptPhone();

  const spinner = ora({
    text   : chalk.cyan('Membuat sesi...'),
    spinner: 'dots12',
    color  : 'cyan',
  }).start();

  // Buat sesi di sessionManager
  const session = createSession(phone);

  spinner.text = chalk.cyan('Menghubungkan ke WhatsApp...');

  // Callback saat pairing code siap
  let pairingShown = false;

  try {
    await connectSession(session.id, phone, (code) => {
      pairingShown = true;
      spinner.stop();

      // Tampilkan pairing code dengan format mencolok
      console.log('');
      console.log(chalk.hex('#FF6D00').bold('  ┌─────────────────────────────────┐'));
      console.log(chalk.hex('#FF6D00').bold('  │       KODE PAIRING WHATSAPP      │'));
      console.log(chalk.hex('#FF6D00').bold('  │                                  │'));
      console.log(chalk.hex('#FFFFFF').bgHex('#FF6D00').bold(`        ${code}        `));
      console.log(chalk.hex('#FF6D00').bold('  │                                  │'));
      console.log(chalk.hex('#FF6D00').bold('  │  Masukkan kode ini di WhatsApp   │'));
      console.log(chalk.hex('#FF6D00').bold('  └─────────────────────────────────┘\n'));
      console.log(chalk.gray(`  Sesi: ${session.id}`));
      console.log(chalk.gray(`  Phone: ${phone}\n`));
    });
  } catch (e) {
    spinner.fail(chalk.red(`Gagal connect: ${e.message}`));
    await pressEnter();
    return;
  }

  if (!pairingShown) spinner.stop();

  info('Setelah memasukkan kode, sesi akan otomatis terhubung.');
  info('Kamu bisa kembali ke menu — koneksi berjalan di background.');
  await pressEnter();
}

/**
 * 2. Mulai warming
 */
async function handleStart() {
  printHeader();
  const sessions = getAllSessions();
  const connected = sessions.filter(s => s.connected);

  if (sessions.length < 2) {
    err('Minimal butuh 2 sesi! Tambah sesi dulu (menu 1).'); await pressEnter(); return;
  }
  if (connected.length < 2) {
    warn(`Hanya ${connected.length} sesi yang terhubung.\nButuh minimal 2 sesi connected.\nTunggu pairing selesai atau tambah sesi.`);
    await pressEnter(); return;
  }

  info(`Akan warming ${connected.length} sesi connected`);
  if (!hasApiKey()) info('Gemini API belum diset → mode random message (70%)');

  const go = await confirm('Mulai warming sekarang?');
  if (!go) return;

  tick();
  const started = startWarming();
  if (started) ok('Warming dimulai! Chat akan terjadi antar sesi secara otomatis.');
  else         info('Warming sudah berjalan.');
  await pressEnter();
}

/**
 * 3. Stop warming
 */
async function handleStop() {
  printHeader();
  if (!isRunning()) { info('Warming tidak berjalan.'); await pressEnter(); return; }
  const go = await confirm('Stop warming sekarang?');
  if (!go) return;
  stopWarming();
  ok('Warming dihentikan. Semua sesi kembali idle.');
  await pressEnter();
}

/**
 * 4. Set API Key Gemini
 */
async function handleApiKey() {
  printHeader();
  info('Set Gemini API Key\n');
  console.log(chalk.gray('  Dapatkan API key gratis di:\n  https://aistudio.google.com/app/apikey\n'));

  const key = await promptApiKey();
  if (!key || key.trim().length < 10) { err('API key tidak valid!'); await pressEnter(); return; }

  const sp = ora({ text: chalk.cyan('Menyimpan...'), spinner:'dots', color:'cyan' }).start();
  await sleep(600);
  setApiKey(key);
  sp.succeed(chalk.green('API key tersimpan!'));
  ok('Gemini AI aktif (30% AI hybrid mode).');
  await pressEnter();
}

/**
 * 5. Statistik
 */
async function handleStats() {
  printHeader();
  console.log(chalk.hex('#00E5FF').bold('  📊 Statistik Per Sesi\n'));
  printStats(getAllSessions());
  await pressEnter();
}

/**
 * 6. Log chat
 */
async function handleLogs() {
  printHeader();
  console.log(chalk.hex('#00E5FF').bold('  💬 Log Chat (35 terbaru)\n'));
  printLogs(liveLog.length ? liveLog : getLatestLogs(35), getAllSessions());
  await pressEnter();
}

/**
 * 7. Daftar sesi
 */
async function handleSessions() {
  printHeader();
  console.log(chalk.hex('#00E5FF').bold('  📱 Daftar Sesi\n'));
  printSessionList(getAllSessions());
  await pressEnter();
}

// ── Main Loop ─────────────────────────────────────────
async function main() {
  // Tick scheduler tiap 5 menit
  setInterval(() => { if (isRunning()) tick(); }, 5 * 60 * 1000);

  while (true) {
    printHeader();
    const stats  = globalStats();
    const period = getTimePeriod();
    printDashboard(stats, period, isRunning(), hasApiKey());

    const choice = await mainMenu(isRunning());
    switch (choice) {
      case '1': await handleAddSession(); break;
      case '2': await handleStart();      break;
      case '3': await handleStop();       break;
      case '4': await handleApiKey();     break;
      case '5': await handleStats();      break;
      case '6': await handleLogs();       break;
      case '7': await handleSessions();   break;
      case '8': {
        const go = await confirm('Yakin keluar? Semua koneksi akan ditutup.');
        if (go) {
          stopWarming();
          for (const s of getAllSessions()) {
            try { await disconnectSession(s.id); } catch (_) {}
          }
          console.log(chalk.hex('#00E5FF')("\n  Sampai jumpa! X'Boy Warming AI Pro\n"));
          process.exit(0);
        }
        break;
      }
    }
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

main().catch(e => {
  console.error(chalk.red('\n  FATAL ERROR:'), e.message);
  console.error(e.stack);
  process.exit(1);
});
