# X'Boy Linux Warming AI Pro v2.0

Real WhatsApp Chat Warming dengan Koneksi Nyata via Pairing Code

---

## 📦 Install

```bash
cd xboy-warming-ai
npm install
```

> Butuh Node.js v18+

---

## 🚀 Jalankan

```bash
npm start
```

---

## 📲 Cara Hubungkan WhatsApp

1. Jalankan `npm start`
2. Pilih **"1. Tambah Sesi"**
3. Masukkan nomor HP format **628xxx** (tanpa +)
4. Kode 8 karakter akan muncul di terminal (contoh: `ABCD-1234`)
5. Buka **WhatsApp** di HP → ⋮ → **Perangkat Tertaut**
6. Ketuk **"Tautkan Perangkat"** → **"Tautkan dengan nomor telepon"**
7. Masukkan kode 8 karakter tersebut
8. Sesi otomatis terhubung ✅
9. Ulangi untuk sesi kedua (min 2 sesi untuk warming)

---

## 🔑 Set API Key Gemini (Opsional)

- Dapatkan API key gratis: https://aistudio.google.com/app/apikey
- Pilih menu **"4. Set API Key"**
- Tanpa API key: tetap jalan dengan random message (70% mode)

---

## 🎯 Cara Warming

1. Tambah minimal **2 sesi** dan **hubungkan keduanya**
2. Pilih **"2. Mulai Warming"**
3. Bot akan otomatis chat antar sesi dengan:
   - Delay realistis (8–45 detik normal, 1–5 menit kadang)
   - Typing simulation nyata
   - Persona berbeda-beda
   - Random emoji & typo

---

## 📁 File Struktur

```
xboy-warming-ai/
├── index.js            # Entry point & main loop
├── config.js           # Konfigurasi global
├── whatsappClient.js   # Koneksi WA real (Baileys)
├── sessionManager.js   # Manajemen sesi
├── personaEngine.js    # Generate persona
├── aiEngine.js         # Hybrid AI (Gemini + random)
├── chatSimulator.js    # Loop warming bot vs bot
├── scheduler.js        # Auto jadwal aktivitas
├── statsTracker.js     # Log & statistik
├── ui.js               # Terminal UI modern
├── sessions/           # Folder auth credentials WA
└── package.json
```

---

## ⚠️ Catatan

- Auth credentials disimpan di folder `sessions/`
- Jangan hapus folder `sessions/` atau harus pairing ulang
- Gunakan secara bertanggung jawab

---

Made with ❤️ by X'Boy — v2.0 Real Connect Edition
